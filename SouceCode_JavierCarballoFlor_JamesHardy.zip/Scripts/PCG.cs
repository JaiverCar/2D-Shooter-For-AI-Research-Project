﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PCG : MonoBehaviour
{
    //////////////////////////////////////////////////////////////////////////
    // DESIGNER ADJUSTABLE VALUES
    //////////////////////////////////////////////////////////////////////////

    //Maximum height and width of tile map (must be odd, somewhere between 21 and 101 works well)
    private int MaxMapSize = 41;
    //Size of floor and wall tiles in Unity units (somewhere between 1.0f and 10.0f works well)
    private float GridSize = 1.0f;

    //////////////////////////////////////////////////////////////////////////

    //Tilemap array to make sure we don't put walls over floors--has no effect during gameplay
    private GameObject[] TileMap;
    //The 0,0 point of the tile map array, since the map goes from -MaxMapSize/2 to +MaxMapSize/2
    private int TileMapMidPoint;

    //A random number generator for this run
	private System.Random RNG;

    //Dictionary of all PCG prefabs
    public Dictionary<string, GameObject> Prefabs;

    //A static reference to allow easy access from other scripts
    //(if you add a "using static PCG;" statement to that script)
    public static PCG PCGObject;

    private List<GameObject> AllGameOBJ = new List<GameObject>();

    //Start is called before the first frame update
    void Start()
    {
        //Store a static reference to this generator
        PCGObject = this;

        //Load all the prefabs into the prefabs dictionary
		LoadPrefabs();

        //Create the tile map
        if (MaxMapSize % 2 == 0)
            ++MaxMapSize; //This needs to be an odd number
		TileMap = new GameObject[MaxMapSize * MaxMapSize];
		TileMapMidPoint = (MaxMapSize * MaxMapSize) / 2; //The 0,0 point

        //Get a new random generator
        //Could feed it a set seed if need the same level for debugging purposes
		RNG = new System.Random();

        //Generate a level
		GenerateLevel();
        GenerateTestRoom();
    }

    //Update is called every frame
    void Update()
    {
        //ESC to quit
        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit(); //Don't need a return from this...
        }

        //T to generate a test room
        if (Input.GetKey(KeyCode.T))
        {
            GenerateTestRoom();
            return;
        }

    }

    //Generate an actual level to play
    void GenerateLevel()
	{
        //Clear any game objects first, just in case
        ClearLevel();

        //Create the camera
        SpawnCamera();

        ///////////////////////////////////////////////////////
        //Add PCG logic here...
        //The level will be solid walls until you add code here. 
        //See the GenerateTestRoom() function for an example,
        //(press T to see the test room).
        //GenerateTestRoom();
        ///////////////////////////////////////////////////////

        //Fill all empty tiles with walls
        FillWithWalls();

        //Do an initial cinematic pan (if desired)
        InitialCinematicPan();
    }

    //Generate a test room with enemies, pick-ups, etc.
    void GenerateTestRoom()
    {
        //Clear any game object first
        ClearLevel();

        //Create the camera
        SpawnCamera();

        //Create the starting tile
        SpawnTile(0, 0);
        Spawn("player", -20.0f, 20.0f);

        //Add some test enemies
        //Spawn("enemy", 7.0f, 7.0f);
        //Spawn("fast", 0.0f, 4.5f);
        //Spawn("tank", 4.5f, 0.0f);
        //Spawn("ultra", -4.5f, 4.5f);
        //Spawn("spread", -4.5f, -4.5f);
        //Spawn("boss", 0.0f, -4.5f);

        //Put a bunch of pick-ups around the player
        //Spawn("heart", 2.0f, 2.0f);
        //Spawn("healthboost", 0.0f, 2.0f);
        //Spawn("speedboost", 2.0f, 0.0f);
        //Spawn("shotboost", 2.0f, -2.0f);
        //Spawn("heart", -2.0f, -2.0f);
        //Spawn("healthboost", 0.0f, -2.0f);
        //Spawn("speedboost", -2.0f, 0.0f);
        //Spawn("shotboost", -2.0f, 2.0f);
        //Spawn("heart", 4.0f, 4.0f);
        //Spawn("healthboost", 2.0f, 4.0f);
        //Spawn("speedboost", 4.0f, 2.0f);
        //Spawn("shotboost", 4.0f, -4.0f);
        //Spawn("heart", -4.0f, -4.0f);
        //Spawn("healthboost", 2.0f, -4.0f);
        //Spawn("speedboost", -4.0f, 2.0f);
        //Spawn("shotboost", -4.0f, 4.0f);

        ////Create a square room
        ////Note that already placed tiles will not be over - written
        //for (int x = -10; x <= 10; x++)
        //    for (int y = -10; y <= 10; y++)
        //        SpawnTile(x, y);

        //Don't forget the exit...
        //Spawn("portal", 8.0f, -8.0f);

        //Fill all empty tiles with walls
        //FillWithWalls();
    }

    //Clear the entire level except for the PCG object
    void ClearLevel()
    {
        //Delete everything       
        for (int i = 0; i < AllGameOBJ.Count; i++)
        {
            UnityEngine.Object.DestroyImmediate(AllGameOBJ[i]);
        }
        //var objsToDelete = FindObjectsOfType<GameObject>();
        //for (int i = 0; i < objsToDelete.Length; i++)
        //{
        //    if (objsToDelete[i].GetComponent<PCG>() == null) //Don't delete the PCG object
        //        UnityEngine.Object.DestroyImmediate(objsToDelete[i]);
        //}
    }

    //Reset the level after a delay
    //This is public so it can be called from other files using the static PCGObject from above
    public void ResetLevel(float delay)
    {
        Invoke("ResetLevel", delay);
    }

    //Reset the level immediately
    //This is public so it can be called from other files using the static PCGObject from above
    public void ResetLevel()
    {
        var currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex);
    }

    //Get a tile object (only walls and floors, currently)
    GameObject GetTile(int x, int y)
	{
		if (Math.Abs(x) > MaxMapSize/2 || Math.Abs(y) > MaxMapSize/2)
			return Prefabs["wall"];
		return TileMap[(y * MaxMapSize) + x + TileMapMidPoint];
	}

	//Spawn a tile object if somthing isn't already there
	void SpawnTile(int x, int y)
	{
		if (GetTile(x,y) != null)
			return;
		TileMap[(y * MaxMapSize) + x + TileMapMidPoint] = Spawn("floor", x, y);
	}

    //Spawn a wall object if something isn't already there
    void SpawnWall(int x, int y)
    {
        if (GetTile(x, y) != null)
            return;
        TileMap[(y * MaxMapSize) + x + TileMapMidPoint] = Spawn("wall", x, y);
    }

    //Fill any empty tiles with walls
    void FillWithWalls()
    {
        for (int x = -MaxMapSize / 2; x <= MaxMapSize / 2; x++)
            for (int y = -MaxMapSize / 2; y <= MaxMapSize / 2; y++)
                SpawnWall(x, y);
    }

    //Spawn any object
    GameObject Spawn(string obj, float x, float y)
	{
        AllGameOBJ.Add(Instantiate(Prefabs[obj], new UnityEngine.Vector3(x * GridSize, y * GridSize, 0.0f), UnityEngine.Quaternion.identity));
        return AllGameOBJ.Last();
	}

	//Spawn any object rotated 90 degrees left
	GameObject SpawnRotateLeft(string obj, float x, float y)
	{
		return Instantiate(Prefabs[obj], new Vector3(x * GridSize, y * GridSize, 0.0f), Quaternion.AngleAxis(-90, Vector3.forward));
	}

	//Spawn any object rotated 90 degrees right
	GameObject SpawnRotateRight(string obj, float x, float y)
	{
		return Instantiate(Prefabs[obj], new Vector3(x * GridSize, y * GridSize, 0.0f), Quaternion.AngleAxis(90, Vector3.forward));
	}

    //Spawn main camera and the weighted camera target
    void SpawnCamera()
    {
        var cam = Instantiate(PCGObject.Prefabs["camera"]);
        AllGameOBJ.Add(cam);
        var wct = Instantiate(PCGObject.Prefabs["cameratarget"]);
        AllGameOBJ.Add(wct);
        cam.GetComponent<CameraFollow>().ObjectToFollow = wct.transform;
    }

    //Try to pan to something of interest
    void InitialCinematicPan()
    {
        //Pan to the first silver key if one exists
        var panTo = GameObject.Find("SilverKey(Clone)");
        //Otherwise pan to the first gold key if one exists
        if (panTo == null)
            panTo = GameObject.Find("GoldKey(Clone)");
        //Otherwise pan to the first boss enemy if one exists
        if (panTo == null)
            panTo = GameObject.Find("BossEnemy(Clone)");
        //Otherwise pan to the first exit portal (which should exist)
        if (panTo == null)
            panTo = GameObject.Find("Portal(Clone)");
        //Did we find something?
        if (panTo == null)
            return;
        //Create a cinematic anchor to pan to, and set it's position
        var cinematicAnchor = Instantiate(PCGObject.Prefabs["cinematicanchor"]);
        cinematicAnchor.transform.position = panTo.transform.position;
	}		

	void LoadPrefabs()
	{
		//Create a prefabs dictionary
        Prefabs = new Dictionary<string, GameObject>();

        //Load all the prefabs we need for map generation (note that these must be in the "Resources" folder)
        Prefabs.Add("floor", Resources.Load<GameObject>("Prefabs/Tiles/Floor"));
        Prefabs["floor"].transform.localScale = new Vector3(GridSize, GridSize, 1.0f); //Scale the floor properly
        Prefabs.Add("special", Resources.Load<GameObject>("Prefabs/Tiles/FloorSpecial"));
        Prefabs["special"].transform.localScale = new Vector3(GridSize, GridSize, 1.0f); //Scale the floor properly
        Prefabs.Add("wall", Resources.Load<GameObject>("Prefabs/Tiles/Wall"));
        Prefabs["wall"].transform.localScale = new Vector3(GridSize, GridSize, 1.0f); //Scale the wall properly
        Prefabs.Add("silverdoor", Resources.Load<GameObject>("Prefabs/Tiles/SilverDoor"));
        Prefabs["silverdoor"].transform.localScale = new Vector3(GridSize, 1.0f, 1.0f); //Scale the door properly
        Prefabs.Add("golddoor", Resources.Load<GameObject>("Prefabs/Tiles/GoldDoor"));
        Prefabs["golddoor"].transform.localScale = new Vector3(GridSize, 1.0f, 1.0f); //Scale the door properly
        Prefabs.Add("portal", Resources.Load<GameObject>("Prefabs/Tiles/Portal"));

        //Load the player prefab
        Prefabs.Add("player", Resources.Load<GameObject>("Prefabs/Player/Player"));

        //Load all the enemy prefabs
        Prefabs.Add("enemy", Resources.Load<GameObject>("Prefabs/Enemies/BaseEnemy"));
        Prefabs.Add("fast", Resources.Load<GameObject>("Prefabs/Enemies/FastEnemy"));
        Prefabs.Add("spread", Resources.Load<GameObject>("Prefabs/Enemies/SpreadEnemy"));
        Prefabs.Add("tank", Resources.Load<GameObject>("Prefabs/Enemies/TankEnemy"));
        Prefabs.Add("ultra", Resources.Load<GameObject>("Prefabs/Enemies/UltraEnemy"));
        Prefabs.Add("boss", Resources.Load<GameObject>("Prefabs/Enemies/BossEnemy"));

		//Load all the pick-ups
        Prefabs.Add("heart", Resources.Load<GameObject>("Prefabs/Pickups/HeartPickup"));
        Prefabs.Add("healthboost", Resources.Load<GameObject>("Prefabs/Pickups/HealthBoost"));
        Prefabs.Add("shotboost", Resources.Load<GameObject>("Prefabs/Pickups/ShotBoost"));
        Prefabs.Add("speedboost", Resources.Load<GameObject>("Prefabs/Pickups/SpeedBoost"));
        Prefabs.Add("silverkey", Resources.Load<GameObject>("Prefabs/Pickups/SilverKey"));
        Prefabs.Add("goldkey", Resources.Load<GameObject>("Prefabs/Pickups/GoldKey"));

        //Load all the camera and UI prefabs
        Prefabs.Add("camera", Resources.Load<GameObject>("Prefabs/Camera/Main Camera"));
        Prefabs.Add("cameratarget", Resources.Load<GameObject>("Prefabs/Camera/WeightedCameraTarget"));
        Prefabs.Add("cinematicanchor", Resources.Load<GameObject>("Prefabs/Camera/CinematicAnchor"));
        Prefabs.Add("uicanvas", Resources.Load<GameObject>("Prefabs/Player/UICanvas"));
    }

}
